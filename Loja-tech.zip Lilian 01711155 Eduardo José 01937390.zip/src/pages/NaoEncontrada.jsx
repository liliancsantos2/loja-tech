import { Link } from "react-router-dom";

function NaoEncontrada() {
  return (
    <main>
      <h2>Erro 404</h2>
      <p>Desculpe, essa página não foi encontrada.</p>

      <Link to="/">Voltar para o início</Link>
    </main>
  );
}

export default NaoEncontrada;