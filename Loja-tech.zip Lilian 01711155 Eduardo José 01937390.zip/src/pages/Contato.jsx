function Contato() {
  function enviarFormulario(event) {
    event.preventDefault();
    alert("Mensagem enviada com sucesso!");
  }

  return (
    <main>
      <h2>Entre em Contato</h2>

      <form onSubmit={enviarFormulario}>
        <label>Nome:</label>
        <input type="text" placeholder="Digite seu nome" required />

        <label>E-mail:</label>
        <input type="email" placeholder="Digite seu e-mail" required />

        <label>Mensagem:</label>
        <textarea placeholder="Digite sua mensagem" required />

        <button type="submit">Enviar</button>
      </form>
    </main>
  );
}

export default Contato;