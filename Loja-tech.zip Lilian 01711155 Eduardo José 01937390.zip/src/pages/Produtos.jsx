import Card from "../components/Card";

function Produtos() {
  const produtos = [
    {
      titulo: "Notebook",
      imagem: "https://placehold.co/200x150?text=Notebook",
      descricao: "Notebook para trabalho e estudo.",
      categoria: "Informática",
      preco: "R$ 2.500,00"
    },
    {
      titulo: "Smartphone",
      imagem: "https://placehold.co/200x150?text=Smartphone",
      descricao: "Celular moderno e rápido.",
      categoria: "Celulares",
      preco: "R$ 1.800,00"
    },
    {
      titulo: "Tablet",
      imagem: "https://placehold.co/200x150?text=Tablet",
      descricao: "Ideal para leitura e estudos.",
      categoria: "Informática",
      preco: "R$ 900,00"
    },
    {
      titulo: "Fone Bluetooth",
      imagem: "https://placehold.co/200x150?text=Fone",
      descricao: "Som sem fio com qualidade.",
      categoria: "Acessórios",
      preco: "R$ 150,00"
    },
    {
      titulo: "Teclado Gamer",
      imagem: "https://placehold.co/200x150?text=Teclado",
      descricao: "Teclado para jogos.",
      categoria: "Acessórios",
      preco: "R$ 250,00"
    },
    {
      titulo: "Mouse",
      imagem: "https://placehold.co/200x150?text=Mouse",
      descricao: "Mouse confortável e preciso.",
      categoria: "Acessórios",
      preco: "R$ 80,00"
    }
  ];

  return (
    <main>
      <h2>Nossos Produtos</h2>

      <div className="lista-produtos">
        {produtos.map((produto, index) => (
          <Card
            key={index}
            titulo={produto.titulo}
            imagem={produto.imagem}
            descricao={produto.descricao}
            categoria={produto.categoria}
            preco={produto.preco}
          />
        ))}
      </div>
    </main>
  );
}

export default Produtos;