function Home() {
  return (
    <main>
      <h2>Bem-vindo à Loja Tech!</h2>

      <p>
        Encontre produtos de tecnologia para facilitar sua vida.
      </p>
    </main>
  );
}

export default Home;