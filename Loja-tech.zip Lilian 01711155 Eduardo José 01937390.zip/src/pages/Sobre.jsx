function Sobre() {
  return (
    <main>
      <h2>Sobre a Loja Tech</h2>

      <p>
        A Loja Tech é uma loja especializada em produtos
        tecnológicos, oferecendo qualidade, inovação e
        praticidade para nossos clientes.
      </p>

      <p>
        Nosso objetivo é facilitar o dia a dia das pessoas
        por meio da tecnologia.
      </p>
    </main>
  );
}

export default Sobre;