
function Footer() {
  return (
    <footer>
      <p>© 2026 Loja Tech - Todos os direitos reservados.</p>
      <p>Desenvolvido com React.</p>
    </footer>
  );
}

export default Footer;
