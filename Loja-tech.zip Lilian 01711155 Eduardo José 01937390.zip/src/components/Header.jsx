
function Header() {
  return (
    <header>
      <h1>Loja Tech</h1>
      <p>Tecnologia para facilitar sua vida!</p>
    </header>
  );
}

export default Header;
