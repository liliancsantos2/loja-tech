
function Card(props) {
  return (
    <div className="Card">
      <img src={props.imagem} alt={props.titulo} />

      <h2>{props.titulo}</h2>

      <p>{props.descricao}</p>

      <p>Categoria: {props.categoria}</p>

      <h3>{props.preco}</h3>
    </div>
  );
}

export default Card;
